﻿using System;
namespace PragueParking
{
    public class MC : Vehicle
    {
        public int size =  2;
        string brand;

        public MC(string regnr, string brand) : base(regnr, 2)
        {

            this.brand = brand;

        }
    }
}
