﻿using System;
using System.Collections.Generic;

namespace PragueParking
{
    public class Parkering
    {
        int availableSlots;
        int parcialSlots;

        private ParkeringPlats[] ParkingSpace;  //Declaring the array...populating will be in the constructor

       


        public Parkering()
        {
            ParkingSpace = new ParkeringPlats[100];

            for (int i = 0; i <= ParkingSpace.Length -1; i++)
            {
                ParkingSpace[i] = new ParkeringPlats();
            }

        }

        public void AddVehicle(int typeOfVehicle, string regnr, string color, string brand)
        {

            int tempSize = DefineSize(typeOfVehicle);

                for (int i = 0; i <= ParkingSpace.Length -1; i++)
                {
                if (ParkingSpace[i].availableSize >= tempSize)
                {
                    ParkingSpace[i].AddFordon(typeOfVehicle, regnr, color, brand);//Call AddFordon to add the Vehicle

                    if (typeOfVehicle == 1)
                    {
                        Console.WriteLine("Car " + regnr + " with color " + color + " added to slot " + (i + 1));

                    }
                    if (typeOfVehicle == 2)
                    {
                        Console.WriteLine("Motocycle " + regnr + " with brand " + brand + " added to slot " + (i + 1));
                    }
                    Console.ReadLine();
                    return;
                }
            }
        }
        public int DefineSize(int vehicleType)
        {
            if (vehicleType == 1)
            {
                return 4;
            }
            if (vehicleType == 2)
            {
                return 2;
            }
            else
            {
                return 0;
            }
        }

        public void Content()
        {
            for (int j = 0; j < ParkingSpace.Length; j++)
            {
                if (ParkingSpace[j].availableSize != 4)
                {
                    ParkingSpace[j].ContentFordon();
                }
            }
            Console.ReadLine();
        }

    }
    //    public void RemoveVehicle();
    //    public void FindVehicle();
    //    public void Content();

}


