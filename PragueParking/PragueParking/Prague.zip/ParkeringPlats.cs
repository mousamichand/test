﻿using System;
using System.Collections.Generic;

namespace PragueParking
{
    public class ParkeringPlats
    {
        public int size { get; private set; }
        public int availableSize { get; private set; }

        public  List<Vehicle> Fordon;

        public ParkeringPlats()
        {
            size = 4;
            availableSize = 4;
            Fordon = new List<Vehicle>();

        }

        public void AddFordon(int typeOfVehicle, string regnr, string color, string brand)
        {
            if (typeOfVehicle == 1)
            {
                Car Bil = new Car(regnr, color);
                Fordon.Add(Bil);
                availableSize = availableSize - Bil.size;
            }
            if (typeOfVehicle == 2)
            {
                MC MB = new MC(regnr, brand);
                Fordon.Add(MB);
                availableSize = availableSize - MB.size;
            }
        }
        public void ContentFordon()
        {
            foreach (Vehicle k  in Fordon)
            {
                if (k.size == 4)
                {
                    Console.WriteLine("CAR " + k.regnr);
                }
                if (k.size == 2)
                {
                    Console.WriteLine("MC " + k.regnr);
                }
            }
        }
    }
}
