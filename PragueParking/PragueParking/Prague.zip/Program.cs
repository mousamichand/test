﻿using System;
using System.Collections.Generic;

namespace PragueParking
{
    class MainClass
    {
       

        //Start of Menu
        public static void DisplayMenu()
        {
            Parkering Park = new Parkering();

            while (true)
            {

                Console.WriteLine("=====================================");
                Console.WriteLine("==========Prague Parking=============");
                Console.WriteLine("=====================================");
                Console.WriteLine("=         Choose an option:         =");
                Console.WriteLine("=====================================");
                Console.WriteLine("= 1. Register vehicle               =");
                Console.WriteLine("= 2. Remove vehicle                 =");
                Console.WriteLine("= 3. Find vehicle                   =");
                Console.WriteLine("= 4. Move vehicle                   =");
                Console.WriteLine("= 5. Current Parking Status         =");
                Console.WriteLine("= 6. Clear the screen               =");
                Console.WriteLine("= 7. Exit Application               =");
                Console.WriteLine("=====================================");
                Console.WriteLine();




                //Menu selection
                int menuSelection = int.Parse(Console.ReadLine());
                string regnr;
                string color;
                string brand;

                switch (menuSelection)
                {
                    case 1: // Register a Vehicle

                        Console.WriteLine("Select the type of Vehicle: ");
                        Console.WriteLine("1. For a Car ");
                        Console.WriteLine("2. For a MC ");
                        int typeOfVehicle = int.Parse(Console.ReadLine());

                        switch (typeOfVehicle)
                        {
                            case 1://Add Car
                                Console.Write("Enter the Registration Number: ");
                                regnr = Console.ReadLine().ToUpper();
                                Console.Write("Enter the color of the Car: ");
                                color = Console.ReadLine().ToUpper();

                                Park.AddVehicle(typeOfVehicle, regnr, color, "");//brand = "" due to constructor parameter requirement

                                Console.WriteLine("Added CAR");//REMOVER
                                break;
                            
                            case 2://Add MB
                                Console.Write("Enter the Registration Number: ");
                                regnr = Console.ReadLine().ToUpper();
                                Console.Write("Enter the brand of the MC: ");
                                brand = Console.ReadLine().ToUpper();

                                Park.AddVehicle(typeOfVehicle, regnr, "", brand);// color = "" due to contructor parameter requirement
                                Console.WriteLine("Added MB");//REMOVER
                                break;

                            case 3:
                                
                                break;
                                
                            
                        }
                        break;

                    case 5:
                        Park.Content();
                        break;

                    case 7:
                        Environment.Exit(1);
                        break;
                }

            }
        }
        //End of Menu
        public static void Main(string[] args)
        {
            
            DisplayMenu();
        }
       
    }
}
