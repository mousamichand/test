﻿using System;
using System.Collections.Generic;

namespace PragueParking
{
    public class Car : Vehicle
    {
        public int size = 4;
        string color;

        public Car(string regnr, string color) : base (regnr, 4)
        {
            
            this.color = color;

        }
    }
}
